.\init.ps1
.\lib.ps1

#initEnv_SI

function CheckService()
{
	Write-Host -ForegroundColor Yellow "=====Start to check service running state====="
	ConfirmServiceRunning $Machine_SSMT SSWinService
	ConfirmServiceRunning $Machine_SSUI SSWebService
	ConfirmServiceRunning $Machine_SSMT AIJobService
}

function CheckDB()
{

}

CheckService
