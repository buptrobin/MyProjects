###########################################################################
##
## init.ps1
## To initialize the environment
##
###########################################################################

# By default is one-box
$LocalName = hostname
$GLOBAL:Machine_SSUI = $LocalName
$GLOBAL:Machine_SSMT = $LocalName
$GLOBAL:Machine_SSDB = $LocalName
$GLOBAL:Machine_RuleFastScoring = $LocalName
$GLOBAL:Machine_TaxonomyFastScoring = $LocalName
$GLOBAL:Machine_MDSMT = $LocalName
$GLOBAL:Machine_MDSDB = $LocalName
$GLOBAL:Machine_DB_AtlasDimension = "CO2APSE071"

$GLOBAL:SG_Access_MDS = "AIS-AudIntClients-SI"
$GLOBAL:SG_Access_COSMOS = "sch-audint-cosmos"
 

function GLOBAL:initEnv_SI(){
	$GLOBAL:Machine_SSUI = "BY2MTZC169"
	$GLOBAL:Machine_SSMT = "BY2MTZC168"
	$GLOBAL:Machine_SSDB = "BY2MTZC643"
	$GLOBAL:Machine_RuleFastScoring = "BY2MTZC641"
	$GLOBAL:Machine_TaxonomyFastScoring = "BY2MTZC642"
	$GLOBAL:Machine_MDSMT = "BY2MTZC619"
	$GLOBAL:Machine_MDSDB = "BY2MTZC620"
	$GLOBAL:Machine_DB_AtlasDimension = $LocalName	

	$GLOBAL:SG_Access_MDS = "AIS-AudIntClients-SI"
	$GLOBAL:SG_Access_COSMOS = "sch-audint-cosmos"
}

function GLOBAL:initEnv_PROD(){
}

.\initSQL.ps1
