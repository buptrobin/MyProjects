###########################################################################
##   lib.ps1
##   The lib for the EVT       
##
###########################################################################

function GLOBAL:CheckServiceState()
{
	param(
		[string]$computerName,
		[string]$serviceName
	)
	
	$ret = [bool]"Fasle"
	Get-Service|Where-Object {$_.Status -eq "Running"}
	$a = Get-Service -ComputerName $computerName -Name $serviceName
	if($a.Status -eq "Running") {
		[bool]$ret = [bool]"True"
	}
	$ret
}

function GLOBAL:CheckServiceExist()
{
	param(
		[string]$computerName,
		[string]$serviceName
	)
	
	#$ret = [bool]"Fasle"
	Get-Service -ComputerName $computerName|Where-Object {$_.Name -eq $serviceName}
}


#--------------------------------------------------------------
# Check the file specified whether exist
# Returen Value: True: exist
#                False: not exist
#--------------------------------------------------------------
function GLOBAL:CheckFileExist()
{
	param(
		[string]$filePath
	)

	Test-Path $filePath
}

#--------------------------------------------------------------
# Check whether the Login in DB logins
# Returen Value: True: exist
#                False: not exist
#--------------------------------------------------------------
function GLOBAL:CheckLoginExist()
{
	param(
		[string] $computerName,
		[string] $loginName
		)
	
	$loginPath = dir SQLSERVER:\SQL\$computerName\DEFAULT\logins |Where-Object {$_.Name -eq $loginName}
	
	$ret = False
	
	if($loginName) {$ret=True}
	
	$ret
}

#--------------------------------------------------------------
# Check whether the Login in DB logins
# Returen Value: True: exist
#                False: not exist
#--------------------------------------------------------------
function GLOBAL:CheckDBExist()
{
	param(
		[string] $computerName,
		[string] $DBName
		)
	
	$dbPath = dir SQLSERVER:\SQL\$computerName\DEFAULT\DATABASE |Where-Object {$_.Name -eq $loginName}

	$ret = False
	
	if($dbPath) {$ret=True}
	
	$ret
}


#--------------------------------------------------------------
# Check whether the Login in DB logins
# Returen Value: True: exist
#                False: not exist
#--------------------------------------------------------------
function GLOBAL:CheckDBLoginExist()
{
	param(
		[string] $computerName,
		[string] $loginName
		)
	
	$loginPath = dir SQLSERVER:\SQL\$computerName\DEFAULT\logins |Where-Object {$_.Name -eq $loginName}
	
	$ret = False
	
	if($loginName) {$ret=True}
	
	$ret
}

#--------------------------------------------------------------
# Check whether the account in the security group
# Returen Value: True: exist
#                False: not exist
#--------------------------------------------------------------
function GLOBAL:CheckAccountInSecurityGroup()
{
	param(
		[string] $account,
		[string] $securityGroup
		)
	
	$loginPath = net group $securityGroup /DOMAIN
	
	$ret = False
	
	if($loginName) {$ret=True}
	
	$ret
}

#---------------------------------------------------------------
# To do check with output
#---------------------------------------------------------------
function GLOBAL:ConfirmServiceRunning(){
	param([string]$computerName, [string]$serviceName)	
	if(CheckServiceExist $computerName $serviceName){	
		$state = CheckServiceState $computerName $serviceName
		if($state){
			Write-Host -ForegroundColor Green "Service $serviceName is running on $computerName"
			# -ForegroundColor Green 
		}
		else{
			Write-Host ("Service $serviceName is not running on $computerName")
			#-ForegroundColor Red 
		}
	}
	else {
		Write-Host -ForegroundColor Red "No service $serviceName on $computerName"
	}
}

function GLOBAL:ConfirmFileExist(){
	param([string]$fileFullPath)
	
	$state = CheckFileExist $fileFullPath
	if($state){
		Write-Host "File {0} is existing" -f $fileFullPath
	}
	else{
		Write-Host "File {0} is not existing" -f $fileFullPath
	}
}

function GLOBAL:ConfirmDBLoginExist(){
	param([string] $computerName,[string] $loginName)
	
	$state = CheckDBLoginExist $computerName $loginName
	if($state){
		Write-Host ("Login {0} is exist in " -f $loginName,$computerName)
	}
	else{
		Write-Host  "Login {0} is not exist in " -f $loginName,$computerName
	}
}


